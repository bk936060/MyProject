# Database Configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '1234',  # Add your MySQL password here
    'database': 'attendance_system',
    'port': 3306
}

# Application Settings
APP_TITLE = "Face Recognition Attendance System"
APP_VERSION = "1.0.0"
WINDOW_SIZE = "1200x680"
MIN_WINDOW_SIZE = (1000, 600)

# Theme Colors (Modern & Colorful)
COLORS = {
    'primary': '#2563eb',      # Blue
    'secondary': '#7c3aed',    # Purple
    'success': '#10b981',      # Green
    'danger': '#ef4444',       # Red
    'warning': '#f59e0b',      # Orange
    'info': '#06b6d4',         # Teal
    'dark': '#1e293b',         # Dark Blue
    'light': '#f8fafc',        # Light Gray
    'bg_dark': '#0f172a',      # Dark Background
    'bg_light': '#ffffff'      # Light Background
}

# Paths
IMAGES_PATH = "images/"
ENCODINGS_PATH = "encodings/"
REPORTS_PATH = "attendance_reports/"

# Face Recognition Settings
FACE_DETECTION_CONFIDENCE = 0.5
FACE_MATCH_THRESHOLD = 0.4
DEEPFACE_MODEL = 'Facenet'  # Options: 'VGG-Face', 'Facenet', 'OpenFace', 'DeepFace'
DEEPFACE_DETECTOR = 'opencv'  # Options: 'opencv', 'ssd', 'mtcnn', 'retinaface'

# Database Table Names
TABLE_USERS = 'users'
TABLE_STUDENTS = 'students'
TABLE_ATTENDANCE = 'attendance'

# UI Settings
FONT_FAMILY = 'Roboto'
FONT_SIZE_NORMAL = 13
FONT_SIZE_HEADING = 20
FONT_SIZE_TITLE = 24
BUTTON_HEIGHT = 40
ENTRY_HEIGHT = 35
